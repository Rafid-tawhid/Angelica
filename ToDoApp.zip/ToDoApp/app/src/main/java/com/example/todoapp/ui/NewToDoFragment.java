package com.example.todoapp.ui;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentResultListener;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.todoapp.databinding.FragmentNewToDoBinding;
import com.example.todoapp.entity.Todo;
import com.example.todoapp.pickers.DatePickerDialogFragment;
import com.example.todoapp.pickers.TimePickerDialogFragment;
import com.example.todoapp.utils.TodoConstants;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class NewToDoFragment extends Fragment {

    private FragmentNewToDoBinding binding;
    private String dateString,timeString;
    int year,month,day,hour,minute;
    private String priority= TodoConstants.Normal;


    public NewToDoFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding=FragmentNewToDoBinding.inflate(inflater,container,false);
        initDateandTime();
        // Inflate the layout for this fragment
        binding.dates.setOnClickListener(view -> {
            new DatePickerDialogFragment().show(getChildFragmentManager(),null);

        });
        binding.times.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                new TimePickerDialogFragment().show(getChildFragmentManager(),null);
            }
        });
        binding.saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String name=binding.ed1.getText().toString();
                final Todo todo=new Todo(name,priority,dateString,timeString,false);

            }
        });


        getChildFragmentManager().setFragmentResultListener(TodoConstants.REQUEST_KEY, this, new FragmentResultListener() {
            @Override
            public void onFragmentResult(@NonNull String requestKey, @NonNull Bundle result) {
                if (result.containsKey(TodoConstants.DATE_KEY)){
                    dateString=result.getString(TodoConstants.DATE_KEY);
                    year=result.getInt(TodoConstants.YEAR);
                    month=result.getInt(TodoConstants.MONTH);
                    day=result.getInt(TodoConstants.DAY);

                    binding.dates.setText(dateString);
                }
                else if(result.containsKey(TodoConstants.TIME_KEY)){
                    timeString=result.getString(TodoConstants.TIME_KEY);
                    hour=result.getInt(TodoConstants.HOUR);
                    minute=result.getInt(TodoConstants.MINUTE);
                    binding.times.setText(timeString);

                }
            }
        });


        return binding.getRoot();
    }
    private void initDateandTime(){
        final Calendar calendar=Calendar.getInstance(Locale.getDefault());

        year=calendar.get(Calendar.YEAR);
        month=calendar.get(Calendar.MONTH);
        day=calendar.get(Calendar.DAY_OF_MONTH);
        hour=calendar.get(Calendar.HOUR);
        minute=calendar.get(Calendar.MINUTE);
        dateString=new SimpleDateFormat("dd/MM/yyy").format(new Date());
        timeString=new SimpleDateFormat("hh:mm a").format(new Date());
        binding.times.setText(timeString);
        binding.dates.setText(dateString);

    }
}