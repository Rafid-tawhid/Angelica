package com.example.todoapp.pickers;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.TimePicker;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.example.todoapp.utils.TodoConstants;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class TimePickerDialogFragment extends DialogFragment implements TimePickerDialog.OnTimeSetListener {



    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        final Calendar calendar=Calendar.getInstance();
        final int hour=calendar.get(Calendar.HOUR_OF_DAY);
        final int minute=calendar.get(Calendar.MINUTE);

        return new TimePickerDialog(getActivity(),this,hour,minute,false);
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        final SimpleDateFormat sdf=new SimpleDateFormat("hh:mm a");
        final Calendar calendar=Calendar.getInstance();
        calendar.set(0,0,0,hourOfDay,minute);
        final String selectedDate=sdf.format(calendar.getTime());
        final Bundle bundle=new Bundle();
        bundle.putString(TodoConstants.TIME_KEY,selectedDate);
        bundle.putInt(TodoConstants.HOUR,hourOfDay);
        bundle.putInt(TodoConstants.MINUTE,minute);
        getParentFragmentManager().setFragmentResult(TodoConstants.REQUEST_KEY,bundle);
    }
}
